A Pen created at CodePen.io. You can find this one at https://codepen.io/Gthibaud/pen/MqpmXE.

 Html integration of rémi's pop-up https://twitter.com/sandwich_cool/status/1031573773294682112